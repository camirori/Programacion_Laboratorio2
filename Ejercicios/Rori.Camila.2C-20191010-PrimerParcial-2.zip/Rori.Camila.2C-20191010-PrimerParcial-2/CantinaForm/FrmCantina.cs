﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace CantinaForm
{
    public partial class FrmCantina : Form
    {
        public FrmCantina()
        {
            InitializeComponent();
        }

        private void FrmCantina_Load(object sender, EventArgs e)
        {
            this.barra.SetCantina = Cantina.GetCantina(10);
            cmbBotellaTipo.DataSource = Enum.GetValues(typeof(Botella.Tipo));
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Botella botella;
            Botella.Tipo tipo;
            if(rBtnAgua.Checked==true)
            {
                botella = new Agua(Convert.ToInt32(numUpDownCapacidad.Value), txtMarca.Text, Convert.ToInt32(numUpDownContenido.Value));
            }
            else
            {
                if(cmbBotellaTipo.SelectedValue==null)
                    botella = new Cerveza(txtMarca.Text, Convert.ToInt32(numUpDownCapacidad.Value), Convert.ToInt32(numUpDownContenido.Value));
                else
                {
                    Enum.TryParse<Botella.Tipo>(cmbBotellaTipo.SelectedValue.ToString(), out tipo);
                    botella = new Cerveza(txtMarca.Text, Convert.ToInt32(numUpDownCapacidad.Value), tipo, Convert.ToInt32(numUpDownContenido.Value));
                }

            }

            this.barra.AgregarBotella(botella);
        }
    }
}
