﻿namespace CantinaForm
{
    partial class FrmCantina
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCantina));
            this.barra = new ControlCantina.Barra();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.cmbBotellaTipo = new System.Windows.Forms.ComboBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.numUpDownContenido = new System.Windows.Forms.NumericUpDown();
            this.numUpDownCapacidad = new System.Windows.Forms.NumericUpDown();
            this.lblContenido = new System.Windows.Forms.Label();
            this.lblCapacidad = new System.Windows.Forms.Label();
            this.txtMarca = new System.Windows.Forms.TextBox();
            this.lblBotellaTipo = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.rBtnAgua = new System.Windows.Forms.RadioButton();
            this.rBtnCerveza = new System.Windows.Forms.RadioButton();
            this.groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownContenido)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownCapacidad)).BeginInit();
            this.SuspendLayout();
            // 
            // barra
            // 
            this.barra.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("barra.BackgroundImage")));
            this.barra.Location = new System.Drawing.Point(12, 12);
            this.barra.Name = "barra";
            this.barra.Size = new System.Drawing.Size(551, 368);
            this.barra.TabIndex = 1;
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.cmbBotellaTipo);
            this.groupBox.Controls.Add(this.btnAgregar);
            this.groupBox.Controls.Add(this.numUpDownContenido);
            this.groupBox.Controls.Add(this.numUpDownCapacidad);
            this.groupBox.Controls.Add(this.lblContenido);
            this.groupBox.Controls.Add(this.lblCapacidad);
            this.groupBox.Controls.Add(this.txtMarca);
            this.groupBox.Controls.Add(this.lblBotellaTipo);
            this.groupBox.Controls.Add(this.lblMarca);
            this.groupBox.Controls.Add(this.rBtnAgua);
            this.groupBox.Controls.Add(this.rBtnCerveza);
            this.groupBox.Location = new System.Drawing.Point(13, 387);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(546, 109);
            this.groupBox.TabIndex = 2;
            this.groupBox.TabStop = false;
            // 
            // cmbBotellaTipo
            // 
            this.cmbBotellaTipo.FormattingEnabled = true;
            this.cmbBotellaTipo.Location = new System.Drawing.Point(301, 39);
            this.cmbBotellaTipo.Name = "cmbBotellaTipo";
            this.cmbBotellaTipo.Size = new System.Drawing.Size(121, 21);
            this.cmbBotellaTipo.TabIndex = 10;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(347, 75);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 9;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // numUpDownContenido
            // 
            this.numUpDownContenido.Location = new System.Drawing.Point(240, 78);
            this.numUpDownContenido.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numUpDownContenido.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDownContenido.Name = "numUpDownContenido";
            this.numUpDownContenido.Size = new System.Drawing.Size(66, 20);
            this.numUpDownContenido.TabIndex = 8;
            this.numUpDownContenido.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // numUpDownCapacidad
            // 
            this.numUpDownCapacidad.Location = new System.Drawing.Point(136, 78);
            this.numUpDownCapacidad.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.numUpDownCapacidad.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDownCapacidad.Name = "numUpDownCapacidad";
            this.numUpDownCapacidad.Size = new System.Drawing.Size(66, 20);
            this.numUpDownCapacidad.TabIndex = 7;
            this.numUpDownCapacidad.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // lblContenido
            // 
            this.lblContenido.AutoSize = true;
            this.lblContenido.Location = new System.Drawing.Point(240, 62);
            this.lblContenido.Name = "lblContenido";
            this.lblContenido.Size = new System.Drawing.Size(55, 13);
            this.lblContenido.TabIndex = 6;
            this.lblContenido.Text = "Contenido";
            // 
            // lblCapacidad
            // 
            this.lblCapacidad.AutoSize = true;
            this.lblCapacidad.Location = new System.Drawing.Point(133, 62);
            this.lblCapacidad.Name = "lblCapacidad";
            this.lblCapacidad.Size = new System.Drawing.Size(58, 13);
            this.lblCapacidad.TabIndex = 5;
            this.lblCapacidad.Text = "Capacidad";
            // 
            // txtMarca
            // 
            this.txtMarca.Location = new System.Drawing.Point(136, 42);
            this.txtMarca.Name = "txtMarca";
            this.txtMarca.Size = new System.Drawing.Size(151, 20);
            this.txtMarca.TabIndex = 4;
            // 
            // lblBotellaTipo
            // 
            this.lblBotellaTipo.AutoSize = true;
            this.lblBotellaTipo.Location = new System.Drawing.Point(298, 22);
            this.lblBotellaTipo.Name = "lblBotellaTipo";
            this.lblBotellaTipo.Size = new System.Drawing.Size(63, 13);
            this.lblBotellaTipo.TabIndex = 3;
            this.lblBotellaTipo.Text = "Botella Tipo";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(133, 26);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(37, 13);
            this.lblMarca.TabIndex = 2;
            this.lblMarca.Text = "Marca";
            // 
            // rBtnAgua
            // 
            this.rBtnAgua.AutoSize = true;
            this.rBtnAgua.Location = new System.Drawing.Point(7, 43);
            this.rBtnAgua.Name = "rBtnAgua";
            this.rBtnAgua.Size = new System.Drawing.Size(50, 17);
            this.rBtnAgua.TabIndex = 1;
            this.rBtnAgua.TabStop = true;
            this.rBtnAgua.Text = "Agua";
            this.rBtnAgua.UseVisualStyleBackColor = true;
            // 
            // rBtnCerveza
            // 
            this.rBtnCerveza.AutoSize = true;
            this.rBtnCerveza.Checked = true;
            this.rBtnCerveza.Location = new System.Drawing.Point(7, 20);
            this.rBtnCerveza.Name = "rBtnCerveza";
            this.rBtnCerveza.Size = new System.Drawing.Size(64, 17);
            this.rBtnCerveza.TabIndex = 0;
            this.rBtnCerveza.TabStop = true;
            this.rBtnCerveza.Text = "Cerveza";
            this.rBtnCerveza.UseVisualStyleBackColor = true;
            // 
            // FrmCantina
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(571, 508);
            this.Controls.Add(this.groupBox);
            this.Controls.Add(this.barra);
            this.Name = "FrmCantina";
            this.Text = "Alumno Camila Rori";
            this.Load += new System.EventHandler(this.FrmCantina_Load);
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownContenido)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownCapacidad)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private ControlCantina.Barra barra;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.ComboBox cmbBotellaTipo;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.NumericUpDown numUpDownContenido;
        private System.Windows.Forms.NumericUpDown numUpDownCapacidad;
        private System.Windows.Forms.Label lblContenido;
        private System.Windows.Forms.Label lblCapacidad;
        private System.Windows.Forms.TextBox txtMarca;
        private System.Windows.Forms.Label lblBotellaTipo;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.RadioButton rBtnAgua;
        private System.Windows.Forms.RadioButton rBtnCerveza;
    }
}