﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cerveza: Botella
    {
        private const int MEDIDA = 330;
        private Tipo tipo;

        #region Metodos
        /// <summary>
        /// Consutructor
        /// </summary>
        /// <param name="marca">Marca de la bebida</param>
        /// <param name="capacidadML">Capacidad de la botella</param>
        /// <param name="contenidoML">Contenido de la botella</param>
        public Cerveza(string marca, int capacidadML, int contenidoML)
            : this(marca, capacidadML,Tipo.Vidrio, contenidoML)
        { }
        public Cerveza(string marca, int capacidadML, Tipo tipo, int contenidoML)
            :base(marca,capacidadML,contenidoML)
        {
            this.tipo = tipo;
        }

        /// <summary>
        /// Retorna todos los datos de la botella
        /// </summary>
        /// <returns>Datos de la botella</returns>
        protected override string GenerarInforme()
        {
            StringBuilder mensaje = new StringBuilder(base.GenerarInforme());
            mensaje.AppendFormat("\nTipo botella: {0}", this.tipo);
            return mensaje.ToString();
        }

        public static implicit operator Botella.Tipo(Cerveza cerveza)
        {
            return cerveza.tipo;
        }

        /// <summary>
        /// Sirve el contenido de la botella
        /// </summary>
        /// <returns>Contenido restante</returns>
        public override int ServirMedida()
        {
            if (MEDIDA <= this.contenidoML)
                this.contenidoML -= (int)(MEDIDA*0.8);
            else
                this.contenidoML = 0;

            return this.contenidoML;
        }

        #endregion
    }
}
