﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Agua: Botella
    {
        private const int MEDIDA = 400;

        #region Metodos
        public Agua(int capacidadML, string marca, int contenidoML)
            : base(marca, capacidadML, contenidoML)
        { }

        protected override string GenerarInforme()
        {
            StringBuilder mensaje = new StringBuilder(base.GenerarInforme());

            return mensaje.ToString();
        }

        public override int ServirMedida()
        {
            return this.ServirMedida(MEDIDA);
        }
        public int ServirMedida(int medida)
        {
            if (medida <= this.contenidoML)
                this.contenidoML -= medida;
            else
                this.contenidoML = 0;

            return this.contenidoML;
        }
        #endregion
    }
}
