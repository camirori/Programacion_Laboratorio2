﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cantina
    {
        private List<Botella> botellas;
        private int espaciosTotales;
        private static Cantina singleton;

        public List<Botella> Botellas
        {
            get { return this.botellas; }
        }

        #region Metodos
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="espacios">Cantidad de espacios disponibles</param>
        private Cantina(int espacios)
        {
            this.botellas = new List<Botella>();
            this.espaciosTotales = espacios;
        }

        /// <summary>
        /// Implementa patròn singleton
        /// </summary>
        /// <param name="espacios">Cantidad de espacios disponibles</param>
        /// <returns>singleton</returns>
        public static Cantina GetCantina(int espacios)
        {
            if (Cantina.singleton == null)
            {
                Cantina.singleton = new Cantina(espacios);
            }
            else
                Cantina.singleton.espaciosTotales = espacios;

            return Cantina.singleton;
        }

        /// <summary>
        /// Agrega una botella a la cantina
        /// </summary>
        /// <param name="c">Cantina</param>
        /// <param name="b">Botella</param>
        /// <returns></returns>
        public static bool operator +(Cantina c, Botella b)
        {
            if(c.botellas.Count()<c.espaciosTotales)
            {
                c.botellas.Add(b);
                return true;
            }
            return false;
        }

        #endregion

    }
}
