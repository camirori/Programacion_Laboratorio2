﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Botella
    {
        #region Campos
        protected int capacidadML;
        protected int contenidoML;
        protected string marca;
        #endregion

        #region Propiedades
        /// <summary>
        /// Retorna capacidad en Litros
        /// </summary>
        public int CapacidadLitros
        {
            get { return (this.capacidadML/1000); }
        }

        public int Contenido
        {
            get { return this.contenidoML; }
            set { this.contenidoML = value; }
        }

        public float PorcentajeContenido
        {
            get { return (((float)this.contenidoML)/this.capacidadML*100); }
        }
        #endregion

        #region Metodos
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="marca">Marca de la bebida</param>
        /// <param name="capacidadML">Capacidad de la botella</param>
        /// <param name="contenidoML">Contenido de la botella</param>
        protected Botella(string marca, int capacidadML, int contenidoML)
        {
            this.marca = marca;
            this.capacidadML = capacidadML;

            if (capacidadML<contenidoML)
                this.contenidoML = capacidadML;
            else
                this.contenidoML = contenidoML;
        }

        /// <summary>
        /// Retorna todos los datos de la botella
        /// </summary>
        /// <returns>Datos de la botella</returns>
        protected virtual string GenerarInforme()
        {
            StringBuilder mensaje = new StringBuilder("");
            mensaje.AppendFormat("\nCapacidad: {0}",this.CapacidadLitros);
            mensaje.AppendFormat("\nContenido: {0}", this.Contenido);
            mensaje.AppendFormat("\nPorcentaje: {0}%", this.PorcentajeContenido);
            mensaje.AppendFormat("\nMarca: {0}", this.marca);
            return mensaje.ToString();
        }

        public abstract int ServirMedida();

        /// <summary>
        /// Retorna todos los datos de la botella
        /// </summary>
        /// <returns>Datos de la botella</returns>
        public override string ToString()
        {
            return this.GenerarInforme();
        }

        #endregion

        public enum Tipo { Plastico, Vidrio }
    }
}
